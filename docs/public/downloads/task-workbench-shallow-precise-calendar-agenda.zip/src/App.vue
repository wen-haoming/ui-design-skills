<script setup lang="ts">
import WorkbenchShallowCalendar from './WorkbenchShallowCalendar.vue';
</script>
<template><WorkbenchShallowCalendar /></template>
