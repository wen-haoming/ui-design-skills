<script setup lang="ts">
import WorkbenchShallowReading from './WorkbenchShallowReading.vue';
</script>
<template><WorkbenchShallowReading /></template>
