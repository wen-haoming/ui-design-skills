import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import path from 'node:path';
export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: [{ find: '../shared', replacement: path.resolve(__dirname, 'shared') }],
  },
});
