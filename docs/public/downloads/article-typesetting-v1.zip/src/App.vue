<script setup lang="ts">
import { ref } from 'vue';
import ArticleTypesetting from './article-typesetting/ArticleTypesetting.vue';
import type { TypographyId } from './article-typesetting/types';
const typo = ref<TypographyId>('reading-longform');
</script>
<template>
  <div style="padding:16px;font-family:system-ui">
    <label>typography <select v-model="typo">
      <option value="reading-longform">reading-longform</option>
      <option value="editorial-magazine">editorial-magazine</option>
      <option value="compact-notes">compact-notes</option>
    </select></label>
    <ArticleTypesetting :typography="typo" article-sample-url="/article-sample.md" />
  </div>
</template>
