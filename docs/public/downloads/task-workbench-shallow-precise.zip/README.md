# task-workbench-shallow-precise

```bash
npm ci
npm run dev
```
