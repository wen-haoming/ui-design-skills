<script setup lang="ts">
import WorkbenchEditorial from './WorkbenchEditorial.vue';
</script>
<template><WorkbenchEditorial /></template>
