<script setup lang="ts">
import WorkbenchShallowBoard from './WorkbenchShallowBoard.vue';
</script>
<template><WorkbenchShallowBoard /></template>
