<script setup lang="ts">
import WorkbenchSoft from './WorkbenchSoft.vue';
</script>
<template><WorkbenchSoft /></template>
