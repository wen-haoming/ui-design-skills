<script setup lang="ts">
import WorkbenchDark from './WorkbenchDark.vue';
</script>
<template><WorkbenchDark /></template>
