# task-workbench-dark-command

```bash
npm ci
npm run dev
```
