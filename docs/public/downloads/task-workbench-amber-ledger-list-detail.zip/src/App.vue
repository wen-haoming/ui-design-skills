<script setup lang="ts">
import WorkbenchAmber from './WorkbenchAmber.vue';
</script>
<template><WorkbenchAmber /></template>
